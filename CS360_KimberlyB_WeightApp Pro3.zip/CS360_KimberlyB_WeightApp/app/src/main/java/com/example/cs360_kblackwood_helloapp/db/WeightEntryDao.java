package com.example.cs360_kblackwood_helloapp.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WeightEntryDao {
    @Insert
    void insert(WeightEntry entry);

    @Query("SELECT * FROM weightentry ")
    List<WeightEntry> getAll();

    @Delete
    void delete(WeightEntry entry);
}
