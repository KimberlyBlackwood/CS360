package com.example.cs360_kblackwood_helloapp.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class WeightEntry {
    @PrimaryKey
    @NonNull
    public String id ="";
    public String weight;
    public String date;


}