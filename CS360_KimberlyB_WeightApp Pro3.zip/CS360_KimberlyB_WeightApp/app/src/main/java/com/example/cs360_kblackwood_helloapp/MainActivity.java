package com.example.cs360_kblackwood_helloapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.cs360_kblackwood_helloapp.ui.login.LoginActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Class<? extends Activity> activityClass;
        Context ctx = this;
        String username = MyApplication.prefs.getString(getString(R.string.prefs_username), null);
        String password = MyApplication.prefs.getString(getString(R.string.prefs_password), null);
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)){
            activityClass = LoginActivity.class;
        }
        else {
            activityClass = WeightEntryActivity.class;
        }
        Intent activity = new Intent(ctx, activityClass);
        ctx.startActivity(activity);

    }
       }






