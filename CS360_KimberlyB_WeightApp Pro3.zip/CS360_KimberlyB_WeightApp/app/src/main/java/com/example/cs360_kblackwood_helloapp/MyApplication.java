package com.example.cs360_kblackwood_helloapp;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import androidx.room.Room;

import com.example.cs360_kblackwood_helloapp.db.AppDatabase;

public class MyApplication extends Application {
    public static AppDatabase db;
    public static SharedPreferences prefs;



    public void onCreate(){
        super.onCreate();
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "auth")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration(true)
                .build();
        prefs = getApplicationContext().getSharedPreferences("prefs", Context.MODE_PRIVATE);



    }

}
