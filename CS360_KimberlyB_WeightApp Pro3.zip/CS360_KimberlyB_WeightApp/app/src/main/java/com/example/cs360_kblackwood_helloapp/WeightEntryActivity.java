package com.example.cs360_kblackwood_helloapp;

import static java.lang.Integer.parseInt;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;

import com.example.cs360_kblackwood_helloapp.db.UserDao;
import com.example.cs360_kblackwood_helloapp.db.WeightEntry;
import com.example.cs360_kblackwood_helloapp.db.WeightEntryDao;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cs360_kblackwood_helloapp.databinding.ActivityWeightEntryBinding;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class WeightEntryActivity extends AppCompatActivity {

    private ActivityWeightEntryBinding binding;
    private EditText mDateInput;
    private EditText mWeightInput;
    private TableLayout mEntriesTable;
    public HashMap<Button, WeightEntry> mEntryMap;

    public  void deleteOnClick(View view){
        Button button = (Button)view;
        TableRow row = (TableRow)button.getParent();
        TableLayout table = (TableLayout)row.getParent();
        table.removeView(row);
        WeightEntry entry = mEntryMap.get(button);

        WeightEntryDao weightEntryDao = MyApplication.db.weightEntryDao();
        weightEntryDao.delete(entry);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityWeightEntryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        CollapsingToolbarLayout toolBarLayout = binding.toolbarLayout;
        toolBarLayout.setTitle(getTitle());
        mEntryMap = new HashMap<Button, WeightEntry>();

        WeightEntryDao weightEntryDao = MyApplication.db.weightEntryDao();
        List<WeightEntry> entries = weightEntryDao.getAll();
        for(WeightEntry entry : entries){
            createRow(entry);
        }
    }

    public void createRow(WeightEntry entry){
        mEntriesTable = (TableLayout) findViewById(R.id.entries_table);

        TableRow row = (TableRow)getLayoutInflater().inflate(R.layout.tablerow, null);
        TextView dateColumn = (TextView)row.findViewById(R.id.tableCellDate);
        TextView weightColumn = (TextView)row.findViewById(R.id.tableCellWeight);
        Button deletebutton = (Button)row.findViewById(R.id.tableCellDelete);
        deletebutton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                deleteOnClick(v);
            }
        });

        dateColumn.setText(entry.date);
        weightColumn.setText(entry.weight);

        mEntryMap.put(deletebutton, entry);
        mEntriesTable.addView(row, new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

    }
    public void showInfoDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("We would like to send periodic messages when you reach goals, etc. Please accept in the following pop-up.");
        builder.setTitle("Permissions Needed");

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User taps OK button.
                // You can directly ask for the permission.
                requestPermissions(
                        new String[] { Manifest.permission.SEND_SMS}, 1
                );
            }
        });

// Create the AlertDialog.
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void sendMessage(Integer weight){
        if (ContextCompat.checkSelfPermission(
                getApplicationContext(), Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED) {
            // You can use the API that requires the permission.
            //performAction(...);
            if (weight <= 150) {
                SmsManager manager = getSystemService(SmsManager.class);
                manager.sendTextMessage("5556", null, "Congratulations on your accomplishment", null, null);
            }
        } else if (ActivityCompat.shouldShowRequestPermissionRationale(
                this, Manifest.permission.SEND_SMS)) {
            // In an educational UI, explain to the user why your app requires this
            // permission for a specific feature to behave as expected, and what
            // features are disabled if it's declined. In this UI, include a
            // "cancel" or "no thanks" button that lets the user continue
            // using your app without granting the permission.
            //showInContextUI(...);
        } else {
            showInfoDialog();


        }

    }
    public void add(View view) {
        mDateInput = (EditText) findViewById(R.id.date_input);
        mWeightInput =(EditText) findViewById(R.id.weight_input);
        try{
            Integer weight = parseInt(mWeightInput.getText().toString());

        WeightEntryDao weightEntryDao = MyApplication.db.weightEntryDao();
        WeightEntry entry = new WeightEntry();
        entry.id = UUID.randomUUID().toString();
        entry.date = mDateInput.getText().toString();
        entry.weight = mWeightInput.getText().toString();
        weightEntryDao.insert(entry);
        createRow(entry);
        sendMessage(weight);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Weight must be an integer!", Toast.LENGTH_LONG).show();
        }
    }
}