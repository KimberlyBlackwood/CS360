package com.example.cs360_kblackwood_helloapp.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDao {
    @Insert
    void insert(User user);

    @Query("SELECT * FROM user WHERE userName LIKE :name AND password LIKE :password LIMIT 1 ")
    User login(String name, String password);
}
