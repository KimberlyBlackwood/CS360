package com.example.cs360_kblackwood_helloapp.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class User{
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String userName;
    public String password;


}