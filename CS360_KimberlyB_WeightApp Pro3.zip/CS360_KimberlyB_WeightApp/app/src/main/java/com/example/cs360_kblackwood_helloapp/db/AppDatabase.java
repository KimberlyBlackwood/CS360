package com.example.cs360_kblackwood_helloapp.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {User.class, WeightEntry.class}, version = 4)
public abstract class AppDatabase extends RoomDatabase {
    public abstract UserDao userDao();
    public abstract WeightEntryDao weightEntryDao();

}
